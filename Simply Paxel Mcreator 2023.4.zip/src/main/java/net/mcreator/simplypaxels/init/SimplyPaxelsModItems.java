/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.simplypaxels.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.client.renderer.item.ClampedItemPropertyFunction;

import net.mcreator.simplypaxels.item.WoodenPaxelItem;
import net.mcreator.simplypaxels.item.StonePaxelItem;
import net.mcreator.simplypaxels.item.NetheritePaxelItem;
import net.mcreator.simplypaxels.item.IronPaxelItem;
import net.mcreator.simplypaxels.item.GoldenPaxelItem;
import net.mcreator.simplypaxels.item.DiamondPaxelItem;
import net.mcreator.simplypaxels.SimplyPaxelsMod;

public class SimplyPaxelsModItems {
	public static Item STONE_PAXEL;
	public static Item WOODEN_PAXEL;
	public static Item IRON_PAXEL;
	public static Item DIAMOND_PAXEL;
	public static Item GOLDEN_PAXEL;
	public static Item NETHERITE_PAXEL;

	public static void load() {
		STONE_PAXEL = register("stone_paxel", new StonePaxelItem());
		WOODEN_PAXEL = register("wooden_paxel", new WoodenPaxelItem());
		IRON_PAXEL = register("iron_paxel", new IronPaxelItem());
		DIAMOND_PAXEL = register("diamond_paxel", new DiamondPaxelItem());
		GOLDEN_PAXEL = register("golden_paxel", new GoldenPaxelItem());
		NETHERITE_PAXEL = register("netherite_paxel", new NetheritePaxelItem());
	}

	public static void clientLoad() {
	}

	private static Item register(String registryName, Item item) {
		return Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(SimplyPaxelsMod.MODID, registryName), item);
	}

	private static void registerBlockingProperty(Item item) {
		ItemProperties.register(item, new ResourceLocation("blocking"), (ClampedItemPropertyFunction) ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
	}
}
