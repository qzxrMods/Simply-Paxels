
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.simplypaxels.init;

import net.mcreator.simplypaxels.procedures.PaxelRightClickProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class SimplyPaxelsModProcedures {
	public static void load() {
		new PaxelRightClickProcedure();
	}
}
